// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//=========================================================
//custom exception for do_custom_application_logic to throw

class uber_exception : virtual public std::exception
{
	
protected:
	std::string m_error_message;

public:
	//constructor (super)
	explicit
	uber_exception(const std::string& message) :
		m_error_message(message) //set error message 
		{}

	//destructor
	virtual ~uber_exception() throw()
	{

	}

	//return the error message
	virtual const char* what() const throw()
	{
		return m_error_message.c_str();
	}
};

//=========================================================

bool do_even_more_custom_application_logic()
{
	//throw standard exception. Didn't know what to put as the message since this function doesnt do much
	throw(std::exception("Something failed!"));
	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}
void do_custom_application_logic()
{

	std::cout << "Running Custom Application Logic." << std::endl;

	//try to call our fail-guaranteed function catching any std::exception
	try
	{
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& e)
	{
		std::cout << "Exception Occurred: " << e.what() << std::endl;
	}

	//throw our custom UBER exception
	throw(uber_exception("Oh no! the UBER EXCEPTION was thrown!"));
	std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
	//throw an invalid_argument exception if 0 is entered as denominator 
	if (den == 0)
	{
		throw(std::invalid_argument("Cannot divide by 0, check arguments"));
	}

	return (num / den);
}

void do_division() noexcept
{

	float numerator = 10.0f;
	float denominator = 0;

	try //to divide
	{
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::invalid_argument& e) //catch only invalid_argument exceptions
	{
		std::cout << "Exception occurred: " << e.what() << std::endl;
	}

}

int main()
{
	std::cout << "Exceptions Tests!" << std::endl;

	try
	{
		do_division();
		do_custom_application_logic();
	}
	catch (const uber_exception& ue)
	{
		std::cout << "Exception occurred: " << ue.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Exception occurred: " << e.what() << std::endl;
	}
	catch (...)
	{
		std::cout << "Uncaught exception occurred!!" << std::endl;
	}

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu